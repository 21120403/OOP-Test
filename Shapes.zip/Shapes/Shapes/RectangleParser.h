﻿#pragma once
#include"IParser.h"
#include"Rectangle\Rectangle.h"

class RectangleParser : public IParser {
public:
    /// <summary>
    /// Lấy các dữ liệu từ chuỗi string truyền vào
    /// </summary>
    /// <param name="Chuỗi string"></param>
    /// <returns>Các dữ liệu đã tách được</returns>
    shared_ptr<Shape> parse(string data)
    {
        stringstream ss(data);
        string temp;
        shared_ptr<Shape> result;
        getline(ss, temp, '=');

        string value1;
        getline(ss, value1, ',');
        float width = stof(value1);

        string temp2;
        getline(ss, temp2, '=');

        string value2;
        getline(ss, value2, '\n');
        float height = stof(value2);
        result = shared_ptr<Shape>(new Rectangle(width, height));
        return result;
    }
};



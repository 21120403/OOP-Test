﻿#pragma once
#include "Shapes.h"
#ifndef RECTANGLE_H
#define RECTANGLE_H

/// <summary>
/// Đối tượng hình học được kế thừa từ class Shape
/// </summary>
class Rectangle : public Shape
{
protected:
	float _w;
	float _h;
public:
	SHAPELIBRARY_API Rectangle(float w, float h);
	SHAPELIBRARY_API float area()override;
	SHAPELIBRARY_API string Info()override;
	SHAPELIBRARY_API float perimeter()override;
	SHAPELIBRARY_API string getType()override;
	SHAPELIBRARY_API float getWidth();
	SHAPELIBRARY_API float getHigh();
	SHAPELIBRARY_API string geoMetricInfo() override;

};
#endif
#pragma once

﻿#include"PrintShape.h"
#ifndef DISPLAYFILE_H
#define DISPLAYFILE_H
/// <summary>
/// Đối tượng được tạo để hiển thị các 
/// dòng dữ liệu sau khi đọc file
/// Kế thừa từ class Display
/// </summary>
class DisplayFile :public Display
{
protected:
	int _countError;//Số dòng lỗi
public:
	DisplayFile();
	/// <summary>
	/// Hàm gán bằng
	/// </summary>
	DisplayFile& operator=(const DisplayFile& other);
	DisplayFile(shared_ptr<shared_ptr<Shape>[]> list, int valueCount, int valueError);
	/// <summary>
	/// Hàm đọc danh sách
	/// </summary>
	void print() override;
};
#endif // !



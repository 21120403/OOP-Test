#pragma once
#include"Shapes.h"
#ifndef CIRCLE_H
#define CIRCLE_H
class Circle : public Shape
{
protected:
	float _r;
public:
	SHAPELIBRARY_API Circle(float value);
	SHAPELIBRARY_API float area()override;
	SHAPELIBRARY_API string Info()override;
	SHAPELIBRARY_API float perimeter()override;
	SHAPELIBRARY_API string getType()override;
	SHAPELIBRARY_API string geoMetricInfo() override;
};

#endif

﻿#include"Shapes.h"
#include<regex>
using std::regex;
/// <summary>
/// sử dụng Singleton để tạo đối tượng Reader đọc file
/// duy nhất một lần trong chương trình
/// </summary>
class Reader
{
private:
	static shared_ptr<Reader>_reader;
	shared_ptr<shared_ptr<string>[]> _readFile;
	int _count;//Đếm số lượng dòng đã đọc
	int _countError;//Đếm số lượng lỗi bắt được
	Reader();
public:
	/// <summary>
	/// Tạo đối tượng Reader
	/// </summary>
	SHAPELIBRARY_API static shared_ptr<Reader> getInstance();
	/// <summary> Hàm lấy ra số dòng đã đọc được</summary>
/// <returns> Số dòng đã đọc: int </returns>
	SHAPELIBRARY_API int getCount();
	/// <summary> Hàm lấy ra số dòng đã đọc bị lỗi</summary>
/// <returns> Số dòng đọc bị lỗi:int  </returns>
	SHAPELIBRARY_API int getCountError();
	/// <summary> Hàm lấy ra danh sách các dòng đã đọc</summary>
/// <returns> Danh sách các dòng đã đọc </returns>
	SHAPELIBRARY_API shared_ptr<shared_ptr<string>[]> getFile();
	/// <summary> Hàm Kiểm tra dữ liệu đầu vào có đúng định dạng không</summary>
/// <returns> Đúng/sai: bool </returns>
	SHAPELIBRARY_API bool isDataLineValid(const string& line);
};



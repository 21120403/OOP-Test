#include"pch.h"
#include"Triangle.h"

Triangle::Triangle(float a, float b, float c)
{
	_a = a;
	_b = b;
	_c = c;
}

float Triangle::area()
{
	// Heron's Formula
	float res = 0;
	float p = perimeter() / 2;
	res = p * (p - _a) * (p - _b) * (p - _c);
	return sqrt(res);
}
string Triangle::Info()
{
	return "Hinh tam giac : Canh a = " + to_string(_a) + " , Canh b = " + to_string(_b) + " , Canh c = " + to_string(_c);
}
float Triangle::perimeter()
{
	return (_a + _b + _c);
}
string Triangle::getType()
{
	return "Triangle";
}
float Triangle::getA()
{
	return _a;
}
float Triangle::getB()
{
	return _b;
}
float Triangle::getC()
{
	return _c;
}
string Triangle::geoMetricInfo()
{ 
	char temp = ',';
	return to_string(_a) + temp + to_string(_b) + temp + to_string(_c);
}
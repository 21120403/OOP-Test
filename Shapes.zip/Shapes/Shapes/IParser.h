﻿#pragma once
#include"Shapes.h"

class IParser
{
public:
    /// <summary>
    /// Lấy các dữ liệu từ chuỗi string truyền vào
    /// </summary>
    /// <param name="Chuỗi string"></param>
    /// <returns>Các dữ liệu đã tách được</returns>
    virtual shared_ptr<Shape> parse(string data) = 0;
    string toString() { return "IParser"; }
};

﻿#pragma once
#include"IParser.h"
#include"Circle/Circle.h"

class CircleParser : public IParser {
public:
    /// <summary>
    /// Lấy các dữ liệu từ chuỗi string truyền vào
    /// </summary>
    /// <param name="Chuỗi string"></param>
    /// <returns>Các dữ liệu đã tách được</returns>
    shared_ptr<Shape> parse(string data)
    {
        stringstream ss(data);
        string temp;
        shared_ptr<Shape> result;
        getline(ss, temp, '=');

        string buffer;
        getline(ss, buffer, '\n');
        float value = stof(buffer);

        result = shared_ptr<Shape>(new Circle(value));
        return result;
    }
};

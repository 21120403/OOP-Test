#include"PrintShape.h"
#ifndef DISPLAYNORMAL_H
#define DISPLAYNORMAL_H
class DisplayNormal :public Display
{
public:
	/// <summary>
	/// Print
	/// </summary>
	SHAPELIBRARY_API void print() override;
	SHAPELIBRARY_API DisplayNormal(shared_ptr<shared_ptr<Shape>[]> list, int valueCount);
	SHAPELIBRARY_API DisplayNormal& operator=(const DisplayNormal& other);
};
#endif // !DISPLAYNORMAL_H
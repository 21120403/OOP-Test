#pragma once
#include"Shapes.h"

class Square : public Shape
{
protected:
	float _a;
public:
	SHAPELIBRARY_API Square(float value);
	SHAPELIBRARY_API float area() override;
	SHAPELIBRARY_API string Info()override;
	SHAPELIBRARY_API float perimeter()override;
	SHAPELIBRARY_API string getType()override;
	SHAPELIBRARY_API float getSide();
	SHAPELIBRARY_API string geoMetricInfo() override;
};

#include"pch.h"
#include"PrintShape.h"
Display::Display()
{
	_listToDisplay = nullptr;
	_count = 0;
}
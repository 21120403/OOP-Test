#include"pch.h"
#include "ListShape.h"
ListShape::ListShape(int valueCount)
{
    _sz = valueCount;
    _list = make_shared<shared_ptr<Shape>[]>(_sz);
}
ListShape::~ListShape()
{
    _list.reset();
}
void ListShape::insert(shared_ptr<Shape> value)
{
    _list[_count] = value;
    _count++;
}
void ListShape::print()
{
    shared_ptr <DisplayNormal> printList = make_shared<DisplayNormal>(_list, _count);
    printList->print();
}
void ListShape::printContentFile(int countError)
{
    shared_ptr<DisplayFile>printList = make_shared<DisplayFile>(_list, _count, countError);
    printList->print();
}
void swap(Shape*& a, Shape*& b)
{
    Shape* temp = a;
    a = b;
    b = temp;
}
void ListShape::mergeSort(int l, int r)
{
    if (l < r)
    {
        int m = l + (r - l) / 2;
        mergeSort(l, m);
        mergeSort(m + 1, r);
        merge(l, m, r);
    }
}
void ListShape::merge(int l, int m, int r)
{
    int i, j, k;
    int n1 = m - l + 1;
    int n2 = r - m;
    shared_ptr<shared_ptr<Shape>[]> L;
    L = make_shared<shared_ptr<Shape>[]>(n1);
    shared_ptr<shared_ptr<Shape>[]> R;
    R = make_shared<shared_ptr<Shape>[]>(n2);
    for (i = 0; i < n1; i++)
        L[i] = _list[l + i];
    for (j = 0; j < n2; j++)
        R[j] = _list[m + 1 + j];
    i = 0;
    j = 0;
    k = l;
    while (i < n1 && j < n2)
    {
        if (L[i]->area() <= R[j]->area())
        {
            _list[k] = L[i];
            i++;
        }
        else
        {
            _list[k] = R[j];
            j++;
        }
        k++;
    }
    while (i < n1)
    {
        _list[k] = L[i];
        i++;
        k++;
    }
    while (j < n2)
    {
        _list[k] = R[j];
        j++;
        k++;
    }
}

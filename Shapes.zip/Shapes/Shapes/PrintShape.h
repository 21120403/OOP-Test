#include"Shapes.h"
#ifndef DISPLAY_H
class Display
{
protected:
	shared_ptr<shared_ptr<Shape>[]> _listToDisplay;
	int _count;
public:
	SHAPELIBRARY_API Display();
	SHAPELIBRARY_API void virtual print() = 0;
};
#define DISPLAY_H
#endif // !DISPLAY_H



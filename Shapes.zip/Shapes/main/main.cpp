﻿#include"Resources.h"
int main()
{
    ParserFactory factory;  // single source of truth
    factory.registerWith("Square", new SquareParser());
    factory.registerWith("Circle", new CircleParser());
    factory.registerWith("Rectangle", new RectangleParser());
    factory.registerWith("Triangle", new TriangleParser());
    factory.registerWith("Parallelogram", new ParallelogramParser());
    shared_ptr<shared_ptr<string>[]> listShapefromFile;
    int count = 0;
    int countError = 0;
    try
    {
        shared_ptr<Reader> a = Reader::getInstance();//Dùng để khởi tạo đối tượng Reader đọc file
        countError = a->getCountError();//Lấy ra số dòng lỗi
        count = a->getCount() - countError;//Lấy ra số dòng đọc được
        listShapefromFile = a->getFile();//Lấy ra danh sách các dòng dữ liệu đọc được
    }
    catch (exception ex)//Bắt lỗi nếu như đọc file thất bại
    {
        cout << "Error: " << ex.what();
    }
    ListShape list(count);
    for (int i = 0; i < count; i++)
    {
        stringstream buffer(*listShapefromFile[i]);
        string type;
        string data;
        getline(buffer, type, ':');
        getline(buffer, data);
        IParser* parser = factory.select(type);
        if (parser != nullptr)
        {
            shared_ptr<Shape> shape = parser->parse(data);
            list.insert(shape);
        }
    }
    list.printContentFile(countError);
    cout << "\n-----------------------------------------------------------------------" << endl << endl;
    list.mergeSort(0, count - 1);
    list.print();

    system("pause");
    return 0;
}
#include"Shapes.h"
#ifndef DISPLAY_H
class Display
{
protected:
	shared_ptr<shared_ptr<Shape>[]> _listToDisplay;
	int _count;
public:
	SHAPELIBRARY_API Display();
	SHAPELIBRARY_API Display(shared_ptr<shared_ptr<Shape>[]> list, int valueCount);
	SHAPELIBRARY_API Display& operator=(const Display& other);
	SHAPELIBRARY_API void virtual print() = 0;
};
#define DISPLAY_H
#endif // !DISPLAY_H



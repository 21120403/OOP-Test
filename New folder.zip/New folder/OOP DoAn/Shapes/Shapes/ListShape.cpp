#include"pch.h"
#include "ListShape.h"
ListShape::ListShape(int valueCount)
{
    _sz = valueCount;
    _list = make_shared<shared_ptr<Shape>[]>(_sz);
}
ListShape::~ListShape()
{
    _list.reset();
}
void ListShape::insert(shared_ptr<Shape> value)
{
    _list[_count] = value;
    _count++;
}
void  ListShape::print()
{
    int choice;
    cout << "Ban muon ra danh sach theo kieu nao, binh thuong hay nang cao ?";
    cout << endl << "1.Binh thuong 2.Nang cao ";
    choice = 1;
    cout << endl;

    if (choice == 1)
    {
        shared_ptr <DisplayNormal> printList = make_shared<DisplayNormal>(_list, _count);
        printList->print();
    }
    else if (choice == 2)
    {

    }
    system("pause");
}

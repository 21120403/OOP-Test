#include"pch.h"
#include"NormalDisplay.h"
DisplayNormal::DisplayNormal(shared_ptr<shared_ptr<Shape>[]> list, int valueCount)
{
	_listToDisplay = list;
	_count = valueCount;
}

void DisplayNormal::print()
{
	for (int i = 0; i < _count; i++)
	{
		cout << std::left << setw(5) << "  |" << setw(3) << i + 1 << setw(3) << "|";
		if (_listToDisplay[i]->getType() == "Circle")
		{
			string temp1 = _listToDisplay[i]->geoMetricInfo();
			float radius;
			radius = stof(temp1);
			cout << setw(19) << "Hinh tron" << setw(3) << "|"
				<< "Ban kinh=" << setw(22) << radius << setw(3) << "|"
				<< "Chu vi=" << setw(8) << fixed << setprecision(1) << _listToDisplay[i]->perimeter() << setw(3) << "|"
				<< "Dien tich=" << setw(9) << fixed << setprecision(2) << _listToDisplay[i]->area() << setw(3) << "|" << endl;
		}
		else if (_listToDisplay[i]->getType() == "Rectangle")
		{
			stringstream ss(_listToDisplay[i]->geoMetricInfo());
			string temp1, temp2;
			float width;
			float high;
			getline(ss, temp1, ',');
			getline(ss, temp2);
			width = stof(temp1);
			high = stof(temp2);
			cout << setw(19) << "Hinh chu nhat" << setw(3) << "|"
				<< "Rong=" << setw(3) << width << ", Cao=" << setw(16) << high << setw(3) << "|"
				<< "Chu vi=" << setw(8) << fixed << setprecision(1) << _listToDisplay[i]->perimeter() << setw(3) << "|"
				<< "Dien tich=" << setw(9) << fixed << setprecision(2) << _listToDisplay[i]->area() << setw(3) << "|" << endl;
		}
		else if (_listToDisplay[i]->getType() == "Square")
		{
			string temp1 = _listToDisplay[i]->geoMetricInfo();
			float side;
			side = stof(temp1);
			cout << setw(19) << "Hinh vuong" << setw(3) << "|"
				<< "Ban kinh=" << setw(22) << side << setw(3) << "|"
				<< "Chu vi=" << setw(8) << fixed << setprecision(1) << _listToDisplay[i]->perimeter() << setw(3) << "|"
				<< "Dien tich=" << setw(9) << fixed << setprecision(2) << _listToDisplay[i]->area() << setw(3) << "|" << endl;
		}
		else if (_listToDisplay[i]->getType() == "Triangle")
		{
			stringstream ss(_listToDisplay[i]->geoMetricInfo());
			string temp1, temp2, temp3;
			float a, b, c;
			getline(ss, temp1, ',');
			getline(ss, temp2, ',');
			getline(ss, temp3);
			a = stof(temp1);
			b = stof(temp2);
			c = stof(temp3);
			cout << setw(19) << "Hinh tam giac" << setw(3) << "|"
				<< "Canh: a=" << fixed << setprecision(2) << a << ", b=" << fixed << setprecision(2) << b << ", c=" << setw(7) << fixed << setprecision(2) << c << setw(3) << "|"
				<< "Chu vi=" << setw(8) << fixed << setprecision(1) << _listToDisplay[i]->perimeter() << setw(3) << "|"
				<< "Dien tich=" << setw(9) << fixed << setprecision(2) << _listToDisplay[i]->area() << setw(3) << "|" << endl;
		}
		else if (_listToDisplay[i]->getType() == "Parallelogram")
		{
			stringstream ss(_listToDisplay[i]->geoMetricInfo());
			string temp1, temp2, temp3;
			float a, b, h;
			getline(ss, temp1, ',');
			getline(ss, temp2, ',');
			getline(ss, temp3);
			a = stof(temp1);
			b = stof(temp2);
			h = stof(temp3);
			cout << setw(19) << "Hinh binh thanh" << setw(3) << "|"
				<< "Canh: a=" << fixed << setprecision(2) << a << ", b=" << fixed << setprecision(2) << b << ", h=" << setw(7) << fixed << setprecision(2) << h << setw(3) << "|"
				<< "Chu vi=" << setw(8) << fixed << setprecision(1) << _listToDisplay[i]->perimeter() << setw(3) << "|"
				<< "Dien tich=" << setw(9) << fixed << setprecision(2) << _listToDisplay[i]->area() << setw(3) << "|" << endl;
		}
	}
}
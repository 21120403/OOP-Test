#pragma once
#ifndef LISTSHAPE_H
#define LISTSHAPE_H
#include "Shapes.h"
#include"PrintShape.h"
#include"NormalDisplay.h"
class ListShape
{
protected:
	shared_ptr<shared_ptr<Shape>[]> _list;
	int _count;
	int _sz;
public:
	SHAPELIBRARY_API ListShape(int valueCount);
	SHAPELIBRARY_API ~ListShape();
	SHAPELIBRARY_API void insert(shared_ptr<Shape>);
	SHAPELIBRARY_API void print();
};

#endif // !LISTSHAPE_H


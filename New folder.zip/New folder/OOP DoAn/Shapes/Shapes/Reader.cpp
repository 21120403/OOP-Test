#include"pch.h"
#include"Reader.h"

shared_ptr<Reader> Reader::_reader = nullptr;

Reader::Reader()
{
	fstream read;
	read.open("shapes.txt", ios::in);
	if (!read.good())
	{
		throw exception("File opening failed");
	}
	else
	{
		string line;
		getline(read, line);
		count = stoi(line);
		_readFile = make_shared<shared_ptr<string>[]>(count);
		for (int i = 0; i < count; i++)
		{
			getline(read, line);
			_readFile[i] = make_shared<string>(line);
		}
	}
	read.close();
}
shared_ptr<Reader> Reader::getInstance()
{
	if (_reader == nullptr)
	{
		_reader = shared_ptr<Reader>(new Reader());
		return _reader;
	}
	return _reader;
}
int Reader::getCount()
{
	return count;
}
shared_ptr<shared_ptr<string>[]>Reader::getFile()
{
	return _readFile;
}

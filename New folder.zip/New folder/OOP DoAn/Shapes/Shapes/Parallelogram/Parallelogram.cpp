#include"pch.h"
#include"Parallelogram.h"

Parallelogram::Parallelogram(float a, float b, float h)
{
	_a = a;
	_b = b;
	_h = h;
}

float Parallelogram::area()
{
	return (_a * _h);
}
string Parallelogram::Info()
{
	return "Hinh binh thanh : Canh a= " + to_string(_a) + " , Canh b = " + to_string(_b) + " , Canh c = " + to_string(_h);
}
float Parallelogram::perimeter()
{
	return (_a + _b) * 2;
}
string Parallelogram::getType()
{
	return "Parallelogram";
}
float Parallelogram::getA()
{
	return _a;
}
float Parallelogram::getB()
{
	return _b;
}
float Parallelogram::getH()
{
	return _h;
}
string Parallelogram::geoMetricInfo()
{
	char temp = ',';
	return to_string(_a) + temp + to_string(_b) + temp + to_string(_h);
}
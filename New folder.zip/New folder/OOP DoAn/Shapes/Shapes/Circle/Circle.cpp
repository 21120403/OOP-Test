#include"pch.h"
#include"Circle.h"
Circle::Circle(float value)
{
	_r = value;
}
float Circle::area()
{
	return _r * _r * 3, 14;
}
float Circle::perimeter()
{
	return _r * 2 * 3, 14;
}
string Circle::Info()
{
	return "Hinh tron: Ban kinh=" + to_string(_r);
}
string Circle::getType()
{
	return "Circle";
}
string Circle::geoMetricInfo()
{
	return to_string(_r);
}
#pragma once

#ifdef SHAPELIBRARY_EXPORTS
#define SHAPELIBRARY_API __declspec(dllexport)
#else
#define SHAPELIBRARY_API __declspec(dllimport)
#endif

#include<iostream>
#include<string>
#include<exception>
#include<memory>
#include<string>
#include<vector>
#include<fstream>
#include<sstream>
#include <iomanip>
#include<math.h>
using std::cin;
using std::cout;
using std::endl;
using std::exception;
using std::shared_ptr;
using std::make_shared;
using std::string;
using std::vector; using std::fstream;
using std::ios;
using std::getline;
using std::stringstream; using std::fixed;
using std::to_string; using std::setprecision; using std::setw;

class Shape
{
public:
	virtual float area() = 0;
	virtual string Info() = 0;
	virtual float perimeter() = 0;
	virtual string getType() = 0;
	virtual string geoMetricInfo() = 0;
};
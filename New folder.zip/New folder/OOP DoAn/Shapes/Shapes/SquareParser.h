#pragma once
#include"IParser.h"
#include"Square/Square.h"

class SquareParser : public IParser {
public:
    shared_ptr<Shape> parse(string data)
    {
        stringstream ss(data);
        string temp;
        shared_ptr<Shape> result;
        getline(ss, temp, '=');

        string buffer;
        getline(ss, buffer, '\n');
        float value = stof(buffer);

        result = shared_ptr<Shape>(new Square(value));
        return result;
    }
};


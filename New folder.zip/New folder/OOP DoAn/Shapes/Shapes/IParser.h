#pragma once
#include"Shapes.h"

class IParser
{
public:
    virtual shared_ptr<Shape> parse(string data) = 0;
    string toString() { return "IParser"; }
};

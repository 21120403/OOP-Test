#include"pch.h"
#include"Square.h"

Square::Square(float value)
{
	_a = value;
}
float Square::area()
{
	return _a * _a;
}
string Square::Info()
{
	return "Hinh vuong : Canh=" + to_string(_a);
}
float Square::perimeter()
{
	return _a * 4;
}
string Square::getType()
{
	return "Square";
}
float Square::getSide()
{
	return _a;
}
string Square::geoMetricInfo()
{
	return to_string(_a);
}
#include"pch.h"
#include"PrintShape.h"
Display::Display()
{
	_listToDisplay = nullptr;
	_count = 0;
}
Display::Display(shared_ptr<shared_ptr<Shape>[]> list, int valueCount)
{
	_listToDisplay = list;
	_count = valueCount;
}
Display& Display::operator=(const Display& other)
{
	if (this != &other)
	{
		_listToDisplay = other._listToDisplay;
		_count = other._count;
	}
	return *this;
}
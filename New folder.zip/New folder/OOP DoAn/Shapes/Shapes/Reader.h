#include"Shapes.h"
class Reader
{
protected:
	static shared_ptr<Reader>_reader;
	shared_ptr<shared_ptr<string>[]> _readFile;
	int count;
	Reader();
public:

	SHAPELIBRARY_API static shared_ptr<Reader> getInstance();
	SHAPELIBRARY_API int getCount();
	SHAPELIBRARY_API shared_ptr<shared_ptr<string>[]> getFile();
};


#include"Resources.h"
int main()
{
    ParserFactory factory;  // single source of truth
    factory.registerWith("Square", new SquareParser());
    factory.registerWith("Circle", new CircleParser());
    factory.registerWith("Rectangle", new RectangleParser());
    factory.registerWith("Triangle", new TriangleParser());
    factory.registerWith("Parallelogram", new ParallelogramParser());
    shared_ptr<shared_ptr<string>[]> listShapefromFile;
    int count = 0;
    try
    {
        shared_ptr<Reader> a = Reader::getInstance();
        count = a->getCount();
        listShapefromFile = a->getFile();
    }
    catch (exception ex)
    {
        cout << "error: " << ex.what();
    }
    ListShape list(count);
    for (int i = 0; i < count; i++)
    {
        stringstream buffer(*listShapefromFile[i]);
        string type;
        string data;
        getline(buffer, type, ':');
        getline(buffer, data);
        IParser* parser = factory.select(type);
        if (parser != nullptr)
        {
            shared_ptr<Shape> shape = parser->parse(data);
            list.insert(shape);
        }
    }
    list.print();

    return 0;
}